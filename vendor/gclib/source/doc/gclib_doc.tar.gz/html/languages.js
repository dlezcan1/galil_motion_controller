var languages =
[
    [ "C/C++", "ccpp.html", "ccpp" ],
    [ "Python", "python.html", null ],
    [ ".Net", "dotnet.html", "dotnet" ]
];