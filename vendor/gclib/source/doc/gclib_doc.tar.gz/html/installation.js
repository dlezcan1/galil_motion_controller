var installation =
[
    [ "Microsoft Windows", "windows.html", null ],
    [ "Apple OS X", "osx.html", null ],
    [ "Ubuntu Linux", "ubuntu.html", null ],
    [ "Fedora Linux", "fedora.html", null ],
    [ "Red Hat 7 & CentOS 7 Linux", "rhel7.html", null ],
    [ "Red Hat 6 & CentOS 6 Linux", "rhel6.html", null ],
    [ "Raspberry Pi", "pi.html", null ]
];