var gclib__record_8h =
[
    [ "GDataRecord4000", "struct_g_data_record4000.html", "struct_g_data_record4000" ],
    [ "GDataRecord52000", "struct_g_data_record52000.html", "struct_g_data_record52000" ],
    [ "GDataRecord1806", "struct_g_data_record1806.html", "struct_g_data_record1806" ],
    [ "GDataRecord2103", "struct_g_data_record2103.html", "struct_g_data_record2103" ],
    [ "GDataRecord1802", "struct_g_data_record1802.html", "struct_g_data_record1802" ],
    [ "GDataRecord30000", "struct_g_data_record30000.html", "struct_g_data_record30000" ],
    [ "GDataRecord47000_ENC", "struct_g_data_record47000___e_n_c.html", "struct_g_data_record47000___e_n_c" ],
    [ "GDataRecord47300_ENC", "struct_g_data_record47300___e_n_c.html", "struct_g_data_record47300___e_n_c" ],
    [ "GDataRecord47300_24EX", "struct_g_data_record47300__24_e_x.html", "struct_g_data_record47300__24_e_x" ],
    [ "GDataRecord", "union_g_data_record.html", "union_g_data_record" ],
    [ "GALILDATARECORDMAXLENGTH", "gclib__record_8h.html#a056e17603c5568fad2c22cf4700dde0b", null ],
    [ "SL", "gclib__record_8h.html#a482d59db094baaac6760774295c6e31b", null ],
    [ "SW", "gclib__record_8h.html#ab4e3d7551d907b6e209e58afbfee023e", null ],
    [ "UB", "gclib__record_8h.html#a1d07b5daeda5428ca8f6fb35f22bdc3f", null ],
    [ "UL", "gclib__record_8h.html#a6294215f8a238bbcc92350c0c00a8673", null ],
    [ "UW", "gclib__record_8h.html#aa2fce981ca730bbd1cc8159277646081", null ]
];