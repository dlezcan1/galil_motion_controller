var NAVTREE =
[
  [ "gclib", "index.html", [
    [ "Getting Started", "index.html", "index" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"struct_g_data_record1802.html#a4c162c666dbbb9d29576c01527e6057e",
"struct_g_data_record2103.html#a5a5c4c3837a742b40be95ab889ce074e",
"struct_g_data_record4000.html#ae42489eda0f4e8dee159958dbb341fb4",
"struct_g_data_record52000.html#ac9bacb16b557c1a517743d31193ad393"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';