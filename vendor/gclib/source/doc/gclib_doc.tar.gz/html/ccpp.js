var ccpp =
[
    [ "Microsoft Visual Studio", "msvc.html", null ],
    [ "MinGW", "mingw.html", null ],
    [ "Borland C++", "borland.html", null ],
    [ "gcc (Linux)", "gcc.html", null ],
    [ "clang  (OS X)", "clang.html", null ]
];