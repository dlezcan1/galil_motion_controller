var legacy =
[
    [ "GalilTools", "gcl.html", null ],
    [ "DMC32 OSU", "dmc32osu.html", null ]
];