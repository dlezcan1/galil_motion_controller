var union_g_data_record =
[
    [ "byte_array", "union_g_data_record.html#a8d30cfed1c935b7a98746e143e78e584", null ],
    [ "dmc1802", "union_g_data_record.html#a7e190b477603138a984bfa08d54d2032", null ],
    [ "dmc1806", "union_g_data_record.html#a6a4450f5c0ce138dff11dcafc4df92c9", null ],
    [ "dmc2103", "union_g_data_record.html#a922da3daf10fb2732bb13ae26cf4dc5a", null ],
    [ "dmc30000", "union_g_data_record.html#afdc7268386f9a1d0904733425c7a3651", null ],
    [ "dmc4000", "union_g_data_record.html#aad07fa16cf6b22c241288ebb55b0db84", null ],
    [ "dmc4103", "union_g_data_record.html#ab020cf7f4a3ba58256b3ece51b111b93", null ],
    [ "dmc50000", "union_g_data_record.html#a108e1e6017638928352d03101bc267dd", null ],
    [ "dmc52000", "union_g_data_record.html#a9e03efe1dfe4769e0e43e63240c945af", null ],
    [ "rio47000", "union_g_data_record.html#ab0e095795e54d52c5dea0b0eb5be8b90", null ],
    [ "rio47300", "union_g_data_record.html#ac8ff667b44c0abd5c4b4b3b67f868a67", null ],
    [ "rio47300_24ex", "union_g_data_record.html#a5550de95e6738d134ba23bc516a1af57", null ]
];