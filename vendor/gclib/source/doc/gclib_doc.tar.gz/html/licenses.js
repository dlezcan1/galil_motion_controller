var licenses =
[
    [ "Closed Source License", "closed_license.html", null ],
    [ "Open Source License", "open_license.html", null ]
];