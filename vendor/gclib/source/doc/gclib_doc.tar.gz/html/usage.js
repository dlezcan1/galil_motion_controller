var usage =
[
    [ "gcaps", "gcaps.html", null ],
    [ "Program Preprocessor", "preprocessor.html", null ],
    [ "Thread Safety", "threading.html", null ],
    [ "Galil Widgets", "widgets.html", null ],
    [ "Rebuilding gclibo", "gclibo.html", null ],
    [ "Software Licenses", "licenses.html", "licenses" ],
    [ "Legacy Compatibility", "legacy.html", "legacy" ]
];