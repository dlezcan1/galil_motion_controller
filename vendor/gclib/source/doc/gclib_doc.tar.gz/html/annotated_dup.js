var annotated_dup =
[
    [ "GDataRecord", "union_g_data_record.html", "union_g_data_record" ],
    [ "GDataRecord1802", "struct_g_data_record1802.html", "struct_g_data_record1802" ],
    [ "GDataRecord1806", "struct_g_data_record1806.html", "struct_g_data_record1806" ],
    [ "GDataRecord2103", "struct_g_data_record2103.html", "struct_g_data_record2103" ],
    [ "GDataRecord30000", "struct_g_data_record30000.html", "struct_g_data_record30000" ],
    [ "GDataRecord4000", "struct_g_data_record4000.html", "struct_g_data_record4000" ],
    [ "GDataRecord47000_ENC", "struct_g_data_record47000___e_n_c.html", "struct_g_data_record47000___e_n_c" ],
    [ "GDataRecord47300_24EX", "struct_g_data_record47300__24_e_x.html", "struct_g_data_record47300__24_e_x" ],
    [ "GDataRecord47300_ENC", "struct_g_data_record47300___e_n_c.html", "struct_g_data_record47300___e_n_c" ],
    [ "GDataRecord52000", "struct_g_data_record52000.html", "struct_g_data_record52000" ],
    [ "H_ArrayData", "struct_h___array_data.html", "struct_h___array_data" ]
];