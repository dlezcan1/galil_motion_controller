var searchData=
[
  ['apple_20os_20x',['Apple OS X',['../osx.html',1,'installation']]]
];
