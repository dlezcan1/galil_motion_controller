var searchData=
[
  ['borland_20c_2b_2b',['Borland C++',['../borland.html',1,'ccpp']]]
];
