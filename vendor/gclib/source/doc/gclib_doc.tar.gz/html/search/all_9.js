var searchData=
[
  ['language_20support',['Language Support',['../languages.html',1,'index']]],
  ['legacy_20compatibility',['Legacy Compatibility',['../legacy.html',1,'usage']]]
];
