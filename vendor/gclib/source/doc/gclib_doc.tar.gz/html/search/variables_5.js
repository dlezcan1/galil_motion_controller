var searchData=
[
  ['general_5fstatus',['general_status',['../struct_g_data_record2103.html#aa14be758e7ed5d55f418b11dd858d97c',1,'GDataRecord2103::general_status()'],['../struct_g_data_record1802.html#aa14be758e7ed5d55f418b11dd858d97c',1,'GDataRecord1802::general_status()'],['../struct_g_data_record47000___e_n_c.html#aa14be758e7ed5d55f418b11dd858d97c',1,'GDataRecord47000_ENC::general_status()'],['../struct_g_data_record47300___e_n_c.html#aa14be758e7ed5d55f418b11dd858d97c',1,'GDataRecord47300_ENC::general_status()'],['../struct_g_data_record47300__24_e_x.html#aa14be758e7ed5d55f418b11dd858d97c',1,'GDataRecord47300_24EX::general_status()']]]
];
