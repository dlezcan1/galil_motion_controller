var searchData=
[
  ['open_20source_20license',['Open Source License',['../open_license.html',1,'licenses']]]
];
