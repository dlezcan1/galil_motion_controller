var searchData=
[
  ['vb_2enet',['VB.NET',['../vb.html',1,'dotnet']]]
];
