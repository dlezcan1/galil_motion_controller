var searchData=
[
  ['software_20licenses',['Software Licenses',['../licenses.html',1,'usage']]]
];
