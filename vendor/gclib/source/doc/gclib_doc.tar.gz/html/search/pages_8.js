var searchData=
[
  ['mingw',['MinGW',['../mingw.html',1,'ccpp']]],
  ['microsoft_20visual_20studio',['Microsoft Visual Studio',['../msvc.html',1,'ccpp']]],
  ['microsoft_20windows',['Microsoft Windows',['../windows.html',1,'installation']]]
];
