var searchData=
[
  ['dmc32_20osu',['DMC32 OSU',['../dmc32osu.html',1,'legacy']]]
];
