var searchData=
[
  ['c_2fc_2b_2b',['C/C++',['../ccpp.html',1,'languages']]],
  ['clang_20_20_28os_20x_29',['clang  (OS X)',['../clang.html',1,'ccpp']]],
  ['closed_20source_20license',['Closed Source License',['../closed_license.html',1,'licenses']]],
  ['c_23_2enet',['C#.NET',['../cs.html',1,'dotnet']]]
];
