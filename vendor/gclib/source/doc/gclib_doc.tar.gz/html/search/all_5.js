var searchData=
[
  ['fedora_20linux',['Fedora Linux',['../fedora.html',1,'installation']]]
];
