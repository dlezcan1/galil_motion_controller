var searchData=
[
  ['ubuntu_20linux',['Ubuntu Linux',['../ubuntu.html',1,'installation']]],
  ['using_20gclib',['Using gclib',['../usage.html',1,'index']]]
];
