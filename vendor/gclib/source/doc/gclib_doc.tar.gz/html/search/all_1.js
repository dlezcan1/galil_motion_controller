var searchData=
[
  ['borland_20c_2b_2b',['Borland C++',['../borland.html',1,'ccpp']]],
  ['byte_5farray',['byte_array',['../union_g_data_record.html#a8d30cfed1c935b7a98746e143e78e584',1,'GDataRecord']]]
];
